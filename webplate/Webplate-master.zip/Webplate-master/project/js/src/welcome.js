/**
 * File: welcome.js
 * Type: Javascipt
 * Author: Chris Humboldt
 */

web.scrollTo({
	offset: -68,
	offsetLarge: -88
});
new buttonplate({
	selector: '.btn-banner'
});