/*! Hammer.JS - v2.0.3 - 2014-09-10
 * http://hammerjs.github.io/
 *
 * Copyright (c) 2014 Jorik Tangelder;
 * Licensed under the MIT license */


! function(a, b, c, d) {
	"use strict";

	function e(a, b, c) {
		return setTimeout(k(a, c), b)
	}

	function f(a, b, c) {
		return Array.isArray(a) ? (g(a, c[b], c), !0) : !1
	}

	function g(a, b, c) {
		var e;
		if (a)
			if (a.forEach) a.forEach(b, c);
			else if (a.length !== d)
			for (e = 0; e < a.length;) b.call(c, a[e], e, a), e++;
		else
			for (e in a) a.hasOwnProperty(e) && b.call(c, a[e], e, a)
	}

	function h(a, b, c) {
		for (var e = Object.keys(b), f = 0; f < e.length;)(!c || c && a[e[f]] === d) && (a[e[f]] = b[e[f]]), f++;
		return a
	}

	function i(a, b) {
		return h(a, b, !0)
	}

	function j(a, b, c) {
		var d, e = b.prototype;
		d = a.prototype = Object.create(e), d.constructor = a, d._super = e, c && h(d, c)
	}

	function k(a, b) {
		return function() {
			return a.apply(b, arguments)
		}
	}

	function l(a, b) {
		return typeof a == ib ? a.apply(b ? b[0] || d : d, b) : a
	}

	function m(a, b) {
		return a === d ? b : a
	}

	function n(a, b, c) {
		g(r(b), function(b) {
			a.addEventListener(b, c, !1)
		})
	}

	function o(a, b, c) {
		g(r(b), function(b) {
			a.removeEventListener(b, c, !1)
		})
	}

	function p(a, b) {
		for (; a;) {
			if (a == b) return !0;
			a = a.parentNode
		}
		return !1
	}

	function q(a, b) {
		return a.indexOf(b) > -1
	}

	function r(a) {
		return a.trim().split(/\s+/g)
	}

	function s(a, b, c) {
		if (a.indexOf && !c) return a.indexOf(b);
		for (var d = 0; d < a.length;) {
			if (c && a[d][c] == b || !c && a[d] === b) return d;
			d++
		}
		return -1
	}

	function t(a) {
		return Array.prototype.slice.call(a, 0)
	}

	function u(a, b, c) {
		for (var d = [], e = [], f = 0; f < a.length;) {
			var g = b ? a[f][b] : a[f];
			s(e, g) < 0 && d.push(a[f]), e[f] = g, f++
		}
		return c && (d = b ? d.sort(function(a, c) {
			return a[b] > c[b]
		}) : d.sort()), d
	}

	function v(a, b) {
		for (var c, e, f = b[0].toUpperCase() + b.slice(1), g = 0; g < gb.length;) {
			if (c = gb[g], e = c ? c + f : b, e in a) return e;
			g++
		}
		return d
	}

	function w() {
		return mb++
	}

	function x(a) {
		var b = a.ownerDocument;
		return b.defaultView || b.parentWindow
	}

	function y(a, b) {
		var c = this;
		this.manager = a, this.callback = b, this.element = a.element, this.target = a.options.inputTarget, this.domHandler = function(b) {
			l(a.options.enable, [a]) && c.handler(b)
		}, this.init()
	}

	function z(a) {
		var b, c = a.options.inputClass;
		return new(b = c ? c : pb ? N : qb ? O : ob ? Q : M)(a, A)
	}

	function A(a, b, c) {
		var d = c.pointers.length,
			e = c.changedPointers.length,
			f = b & wb && d - e === 0,
			g = b & (yb | zb) && d - e === 0;
		c.isFirst = !!f, c.isFinal = !!g, f && (a.session = {}), c.eventType = b, B(a, c), a.emit("hammer.input", c), a.recognize(c), a.session.prevInput = c
	}

	function B(a, b) {
		var c = a.session,
			d = b.pointers,
			e = d.length;
		c.firstInput || (c.firstInput = E(b)), e > 1 && !c.firstMultiple ? c.firstMultiple = E(b) : 1 === e && (c.firstMultiple = !1);
		var f = c.firstInput,
			g = c.firstMultiple,
			h = g ? g.center : f.center,
			i = b.center = F(d);
		b.timeStamp = lb(), b.deltaTime = b.timeStamp - f.timeStamp, b.angle = J(h, i), b.distance = I(h, i), C(c, b), b.offsetDirection = H(b.deltaX, b.deltaY), b.scale = g ? L(g.pointers, d) : 1, b.rotation = g ? K(g.pointers, d) : 0, D(c, b);
		var j = a.element;
		p(b.srcEvent.target, j) && (j = b.srcEvent.target), b.target = j
	}

	function C(a, b) {
		var c = b.center,
			d = a.offsetDelta || {},
			e = a.prevDelta || {},
			f = a.prevInput || {};
		(b.eventType === wb || f.eventType === yb) && (e = a.prevDelta = {
			x: f.deltaX || 0,
			y: f.deltaY || 0
		}, d = a.offsetDelta = {
			x: c.x,
			y: c.y
		}), b.deltaX = e.x + (c.x - d.x), b.deltaY = e.y + (c.y - d.y)
	}

	function D(a, b) {
		var c, e, f, g, h = a.lastInterval || b,
			i = b.timeStamp - h.timeStamp;
		if (b.eventType != zb && (i > vb || h.velocity === d)) {
			var j = h.deltaX - b.deltaX,
				k = h.deltaY - b.deltaY,
				l = G(i, j, k);
			e = l.x, f = l.y, c = kb(l.x) > kb(l.y) ? l.x : l.y, g = H(j, k), a.lastInterval = b
		} else c = h.velocity, e = h.velocityX, f = h.velocityY, g = h.direction;
		b.velocity = c, b.velocityX = e, b.velocityY = f, b.direction = g
	}

	function E(a) {
		for (var b = [], c = 0; c < a.pointers.length;) b[c] = {
			clientX: jb(a.pointers[c].clientX),
			clientY: jb(a.pointers[c].clientY)
		}, c++;
		return {
			timeStamp: lb(),
			pointers: b,
			center: F(b),
			deltaX: a.deltaX,
			deltaY: a.deltaY
		}
	}

	function F(a) {
		var b = a.length;
		if (1 === b) return {
			x: jb(a[0].clientX),
			y: jb(a[0].clientY)
		};
		for (var c = 0, d = 0, e = 0; b > e;) c += a[e].clientX, d += a[e].clientY, e++;
		return {
			x: jb(c / b),
			y: jb(d / b)
		}
	}

	function G(a, b, c) {
		return {
			x: b / a || 0,
			y: c / a || 0
		}
	}

	function H(a, b) {
		return a === b ? Ab : kb(a) >= kb(b) ? a > 0 ? Bb : Cb : b > 0 ? Db : Eb
	}

	function I(a, b, c) {
		c || (c = Ib);
		var d = b[c[0]] - a[c[0]],
			e = b[c[1]] - a[c[1]];
		return Math.sqrt(d * d + e * e)
	}

	function J(a, b, c) {
		c || (c = Ib);
		var d = b[c[0]] - a[c[0]],
			e = b[c[1]] - a[c[1]];
		return 180 * Math.atan2(e, d) / Math.PI
	}

	function K(a, b) {
		return J(b[1], b[0], Jb) - J(a[1], a[0], Jb)
	}

	function L(a, b) {
		return I(b[0], b[1], Jb) / I(a[0], a[1], Jb)
	}

	function M() {
		this.evEl = Lb, this.evWin = Mb, this.allow = !0, this.pressed = !1, y.apply(this, arguments)
	}

	function N() {
		this.evEl = Pb, this.evWin = Qb, y.apply(this, arguments), this.store = this.manager.session.pointerEvents = []
	}

	function O() {
		this.evTarget = Sb, this.targetIds = {}, y.apply(this, arguments)
	}

	function P(a, b) {
		var c = t(a.touches),
			d = this.targetIds;
		if (b & (wb | xb) && 1 === c.length) return d[c[0].identifier] = !0, [c, c];
		var e, f = t(a.targetTouches),
			g = t(a.changedTouches),
			h = [];
		if (b === wb)
			for (e = 0; e < f.length;) d[f[e].identifier] = !0, e++;
		for (e = 0; e < g.length;) d[g[e].identifier] && h.push(g[e]), b & (yb | zb) && delete d[g[e].identifier], e++;
		return h.length ? [u(f.concat(h), "identifier", !0), h] : void 0
	}

	function Q() {
		y.apply(this, arguments);
		var a = k(this.handler, this);
		this.touch = new O(this.manager, a), this.mouse = new M(this.manager, a)
	}

	function R(a, b) {
		this.manager = a, this.set(b)
	}

	function S(a) {
		if (q(a, Yb)) return Yb;
		var b = q(a, Zb),
			c = q(a, $b);
		return b && c ? Zb + " " + $b : b || c ? b ? Zb : $b : q(a, Xb) ? Xb : Wb
	}

	function T(a) {
		this.id = w(), this.manager = null, this.options = i(a || {}, this.defaults), this.options.enable = m(this.options.enable, !0), this.state = _b, this.simultaneous = {}, this.requireFail = []
	}

	function U(a) {
		return a & ec ? "cancel" : a & cc ? "end" : a & bc ? "move" : a & ac ? "start" : ""
	}

	function V(a) {
		return a == Eb ? "down" : a == Db ? "up" : a == Bb ? "left" : a == Cb ? "right" : ""
	}

	function W(a, b) {
		var c = b.manager;
		return c ? c.get(a) : a
	}

	function X() {
		T.apply(this, arguments)
	}

	function Y() {
		X.apply(this, arguments), this.pX = null, this.pY = null
	}

	function Z() {
		X.apply(this, arguments)
	}

	function $() {
		T.apply(this, arguments), this._timer = null, this._input = null
	}

	function _() {
		X.apply(this, arguments)
	}

	function ab() {
		X.apply(this, arguments)
	}

	function bb() {
		T.apply(this, arguments), this.pTime = !1, this.pCenter = !1, this._timer = null, this._input = null, this.count = 0
	}

	function cb(a, b) {
		return b = b || {}, b.recognizers = m(b.recognizers, cb.defaults.preset), new db(a, b)
	}

	function db(a, b) {
		b = b || {}, this.options = i(b, cb.defaults), this.options.inputTarget = this.options.inputTarget || a, this.handlers = {}, this.session = {}, this.recognizers = [], this.element = a, this.input = z(this), this.touchAction = new R(this, this.options.touchAction), eb(this, !0), g(b.recognizers, function(a) {
			var b = this.add(new a[0](a[1]));
			a[2] && b.recognizeWith(a[2]), a[3] && b.requireFailure(a[3])
		}, this)
	}

	function eb(a, b) {
		var c = a.element;
		g(a.options.cssProps, function(a, d) {
			c.style[v(c.style, d)] = b ? a : ""
		})
	}

	function fb(a, c) {
		var d = b.createEvent("Event");
		d.initEvent(a, !0, !0), d.gesture = c, c.target.dispatchEvent(d)
	}
	var gb = ["", "webkit", "moz", "MS", "ms", "o"],
		hb = b.createElement("div"),
		ib = "function",
		jb = Math.round,
		kb = Math.abs,
		lb = Date.now,
		mb = 1,
		nb = /mobile|tablet|ip(ad|hone|od)|android/i,
		ob = "ontouchstart" in a,
		pb = v(a, "PointerEvent") !== d,
		qb = ob && nb.test(navigator.userAgent),
		rb = "touch",
		sb = "pen",
		tb = "mouse",
		ub = "kinect",
		vb = 25,
		wb = 1,
		xb = 2,
		yb = 4,
		zb = 8,
		Ab = 1,
		Bb = 2,
		Cb = 4,
		Db = 8,
		Eb = 16,
		Fb = Bb | Cb,
		Gb = Db | Eb,
		Hb = Fb | Gb,
		Ib = ["x", "y"],
		Jb = ["clientX", "clientY"];
	y.prototype = {
		handler: function() {},
		init: function() {
			this.evEl && n(this.element, this.evEl, this.domHandler), this.evTarget && n(this.target, this.evTarget, this.domHandler), this.evWin && n(x(this.element), this.evWin, this.domHandler)
		},
		destroy: function() {
			this.evEl && o(this.element, this.evEl, this.domHandler), this.evTarget && o(this.target, this.evTarget, this.domHandler), this.evWin && o(x(this.element), this.evWin, this.domHandler)
		}
	};
	var Kb = {
			mousedown: wb,
			mousemove: xb,
			mouseup: yb
		},
		Lb = "mousedown",
		Mb = "mousemove mouseup";
	j(M, y, {
		handler: function(a) {
			var b = Kb[a.type];
			b & wb && 0 === a.button && (this.pressed = !0), b & xb && 1 !== a.which && (b = yb), this.pressed && this.allow && (b & yb && (this.pressed = !1), this.callback(this.manager, b, {
				pointers: [a],
				changedPointers: [a],
				pointerType: tb,
				srcEvent: a
			}))
		}
	});
	var Nb = {
			pointerdown: wb,
			pointermove: xb,
			pointerup: yb,
			pointercancel: zb,
			pointerout: zb
		},
		Ob = {
			2: rb,
			3: sb,
			4: tb,
			5: ub
		},
		Pb = "pointerdown",
		Qb = "pointermove pointerup pointercancel";
	a.MSPointerEvent && (Pb = "MSPointerDown", Qb = "MSPointerMove MSPointerUp MSPointerCancel"), j(N, y, {
		handler: function(a) {
			var b = this.store,
				c = !1,
				d = a.type.toLowerCase().replace("ms", ""),
				e = Nb[d],
				f = Ob[a.pointerType] || a.pointerType,
				g = f == rb;
			e & wb && (0 === a.button || g) ? b.push(a) : e & (yb | zb) && (c = !0);
			var h = s(b, a.pointerId, "pointerId");
			0 > h || (b[h] = a, this.callback(this.manager, e, {
				pointers: b,
				changedPointers: [a],
				pointerType: f,
				srcEvent: a
			}), c && b.splice(h, 1))
		}
	});
	var Rb = {
			touchstart: wb,
			touchmove: xb,
			touchend: yb,
			touchcancel: zb
		},
		Sb = "touchstart touchmove touchend touchcancel";
	j(O, y, {
		handler: function(a) {
			var b = Rb[a.type],
				c = P.call(this, a, b);
			c && this.callback(this.manager, b, {
				pointers: c[0],
				changedPointers: c[1],
				pointerType: rb,
				srcEvent: a
			})
		}
	}), j(Q, y, {
		handler: function(a, b, c) {
			var d = c.pointerType == rb,
				e = c.pointerType == tb;
			if (d) this.mouse.allow = !1;
			else if (e && !this.mouse.allow) return;
			b & (yb | zb) && (this.mouse.allow = !0), this.callback(a, b, c)
		},
		destroy: function() {
			this.touch.destroy(), this.mouse.destroy()
		}
	});
	var Tb = v(hb.style, "touchAction"),
		Ub = Tb !== d,
		Vb = "compute",
		Wb = "auto",
		Xb = "manipulation",
		Yb = "none",
		Zb = "pan-x",
		$b = "pan-y";
	R.prototype = {
		set: function(a) {
			a == Vb && (a = this.compute()), Ub && (this.manager.element.style[Tb] = a), this.actions = a.toLowerCase().trim()
		},
		update: function() {
			this.set(this.manager.options.touchAction)
		},
		compute: function() {
			var a = [];
			return g(this.manager.recognizers, function(b) {
				l(b.options.enable, [b]) && (a = a.concat(b.getTouchAction()))
			}), S(a.join(" "))
		},
		preventDefaults: function(a) {
			if (!Ub) {
				var b = a.srcEvent,
					c = a.offsetDirection;
				if (this.manager.session.prevented) return void b.preventDefault();
				var d = this.actions,
					e = q(d, Yb),
					f = q(d, $b),
					g = q(d, Zb);
				return e || f && c & Fb || g && c & Gb ? this.preventSrc(b) : void 0
			}
		},
		preventSrc: function(a) {
			this.manager.session.prevented = !0, a.preventDefault()
		}
	};
	var _b = 1,
		ac = 2,
		bc = 4,
		cc = 8,
		dc = cc,
		ec = 16,
		fc = 32;
	T.prototype = {
		defaults: {},
		set: function(a) {
			return h(this.options, a), this.manager && this.manager.touchAction.update(), this
		},
		recognizeWith: function(a) {
			if (f(a, "recognizeWith", this)) return this;
			var b = this.simultaneous;
			return a = W(a, this), b[a.id] || (b[a.id] = a, a.recognizeWith(this)), this
		},
		dropRecognizeWith: function(a) {
			return f(a, "dropRecognizeWith", this) ? this : (a = W(a, this), delete this.simultaneous[a.id], this)
		},
		requireFailure: function(a) {
			if (f(a, "requireFailure", this)) return this;
			var b = this.requireFail;
			return a = W(a, this), -1 === s(b, a) && (b.push(a), a.requireFailure(this)), this
		},
		dropRequireFailure: function(a) {
			if (f(a, "dropRequireFailure", this)) return this;
			a = W(a, this);
			var b = s(this.requireFail, a);
			return b > -1 && this.requireFail.splice(b, 1), this
		},
		hasRequireFailures: function() {
			return this.requireFail.length > 0
		},
		canRecognizeWith: function(a) {
			return !!this.simultaneous[a.id]
		},
		emit: function(a) {
			function b(b) {
				c.manager.emit(c.options.event + (b ? U(d) : ""), a)
			}
			var c = this,
				d = this.state;
			cc > d && b(!0), b(), d >= cc && b(!0)
		},
		tryEmit: function(a) {
			return this.canEmit() ? this.emit(a) : void(this.state = fc)
		},
		canEmit: function() {
			for (var a = 0; a < this.requireFail.length;) {
				if (!(this.requireFail[a].state & (fc | _b))) return !1;
				a++
			}
			return !0
		},
		recognize: function(a) {
			var b = h({}, a);
			return l(this.options.enable, [this, b]) ? (this.state & (dc | ec | fc) && (this.state = _b), this.state = this.process(b), void(this.state & (ac | bc | cc | ec) && this.tryEmit(b))) : (this.reset(), void(this.state = fc))
		},
		process: function() {},
		getTouchAction: function() {},
		reset: function() {}
	}, j(X, T, {
		defaults: {
			pointers: 1
		},
		attrTest: function(a) {
			var b = this.options.pointers;
			return 0 === b || a.pointers.length === b
		},
		process: function(a) {
			var b = this.state,
				c = a.eventType,
				d = b & (ac | bc),
				e = this.attrTest(a);
			return d && (c & zb || !e) ? b | ec : d || e ? c & yb ? b | cc : b & ac ? b | bc : ac : fc
		}
	}), j(Y, X, {
		defaults: {
			event: "pan",
			threshold: 10,
			pointers: 1,
			direction: Hb
		},
		getTouchAction: function() {
			var a = this.options.direction,
				b = [];
			return a & Fb && b.push($b), a & Gb && b.push(Zb), b
		},
		directionTest: function(a) {
			var b = this.options,
				c = !0,
				d = a.distance,
				e = a.direction,
				f = a.deltaX,
				g = a.deltaY;
			return e & b.direction || (b.direction & Fb ? (e = 0 === f ? Ab : 0 > f ? Bb : Cb, c = f != this.pX, d = Math.abs(a.deltaX)) : (e = 0 === g ? Ab : 0 > g ? Db : Eb, c = g != this.pY, d = Math.abs(a.deltaY))), a.direction = e, c && d > b.threshold && e & b.direction
		},
		attrTest: function(a) {
			return X.prototype.attrTest.call(this, a) && (this.state & ac || !(this.state & ac) && this.directionTest(a))
		},
		emit: function(a) {
			this.pX = a.deltaX, this.pY = a.deltaY;
			var b = V(a.direction);
			b && this.manager.emit(this.options.event + b, a), this._super.emit.call(this, a)
		}
	}), j(Z, X, {
		defaults: {
			event: "pinch",
			threshold: 0,
			pointers: 2
		},
		getTouchAction: function() {
			return [Yb]
		},
		attrTest: function(a) {
			return this._super.attrTest.call(this, a) && (Math.abs(a.scale - 1) > this.options.threshold || this.state & ac)
		},
		emit: function(a) {
			if (this._super.emit.call(this, a), 1 !== a.scale) {
				var b = a.scale < 1 ? "in" : "out";
				this.manager.emit(this.options.event + b, a)
			}
		}
	}), j($, T, {
		defaults: {
			event: "press",
			pointers: 1,
			time: 500,
			threshold: 5
		},
		getTouchAction: function() {
			return [Wb]
		},
		process: function(a) {
			var b = this.options,
				c = a.pointers.length === b.pointers,
				d = a.distance < b.threshold,
				f = a.deltaTime > b.time;
			if (this._input = a, !d || !c || a.eventType & (yb | zb) && !f) this.reset();
			else if (a.eventType & wb) this.reset(), this._timer = e(function() {
				this.state = dc, this.tryEmit()
			}, b.time, this);
			else if (a.eventType & yb) return dc;
			return fc
		},
		reset: function() {
			clearTimeout(this._timer)
		},
		emit: function(a) {
			this.state === dc && (a && a.eventType & yb ? this.manager.emit(this.options.event + "up", a) : (this._input.timeStamp = lb(), this.manager.emit(this.options.event, this._input)))
		}
	}), j(_, X, {
		defaults: {
			event: "rotate",
			threshold: 0,
			pointers: 2
		},
		getTouchAction: function() {
			return [Yb]
		},
		attrTest: function(a) {
			return this._super.attrTest.call(this, a) && (Math.abs(a.rotation) > this.options.threshold || this.state & ac)
		}
	}), j(ab, X, {
		defaults: {
			event: "swipe",
			threshold: 10,
			velocity: .65,
			direction: Fb | Gb,
			pointers: 1
		},
		getTouchAction: function() {
			return Y.prototype.getTouchAction.call(this)
		},
		attrTest: function(a) {
			var b, c = this.options.direction;
			return c & (Fb | Gb) ? b = a.velocity : c & Fb ? b = a.velocityX : c & Gb && (b = a.velocityY), this._super.attrTest.call(this, a) && c & a.direction && a.distance > this.options.threshold && kb(b) > this.options.velocity && a.eventType & yb
		},
		emit: function(a) {
			var b = V(a.direction);
			b && this.manager.emit(this.options.event + b, a), this.manager.emit(this.options.event, a)
		}
	}), j(bb, T, {
		defaults: {
			event: "tap",
			pointers: 1,
			taps: 1,
			interval: 300,
			time: 250,
			threshold: 2,
			posThreshold: 10
		},
		getTouchAction: function() {
			return [Xb]
		},
		process: function(a) {
			var b = this.options,
				c = a.pointers.length === b.pointers,
				d = a.distance < b.threshold,
				f = a.deltaTime < b.time;
			if (this.reset(), a.eventType & wb && 0 === this.count) return this.failTimeout();
			if (d && f && c) {
				if (a.eventType != yb) return this.failTimeout();
				var g = this.pTime ? a.timeStamp - this.pTime < b.interval : !0,
					h = !this.pCenter || I(this.pCenter, a.center) < b.posThreshold;
				this.pTime = a.timeStamp, this.pCenter = a.center, h && g ? this.count += 1 : this.count = 1, this._input = a;
				var i = this.count % b.taps;
				if (0 === i) return this.hasRequireFailures() ? (this._timer = e(function() {
					this.state = dc, this.tryEmit()
				}, b.interval, this), ac) : dc
			}
			return fc
		},
		failTimeout: function() {
			return this._timer = e(function() {
				this.state = fc
			}, this.options.interval, this), fc
		},
		reset: function() {
			clearTimeout(this._timer)
		},
		emit: function() {
			this.state == dc && (this._input.tapCount = this.count, this.manager.emit(this.options.event, this._input))
		}
	}), cb.VERSION = "2.0.3", cb.defaults = {
		domEvents: !1,
		touchAction: Vb,
		enable: !0,
		inputTarget: null,
		inputClass: null,
		preset: [
			[_, {
				enable: !1
			}],
			[Z, {
					enable: !1
				},
				["rotate"]
			],
			[ab, {
				direction: Fb
			}],
			[Y, {
					direction: Fb
				},
				["swipe"]
			],
			[bb],
			[bb, {
					event: "doubletap",
					taps: 2
				},
				["tap"]
			],
			[$]
		],
		cssProps: {
			userSelect: "none",
			touchSelect: "none",
			touchCallout: "none",
			contentZooming: "none",
			userDrag: "none",
			tapHighlightColor: "rgba(0,0,0,0)"
		}
	};
	var gc = 1,
		hc = 2;
	db.prototype = {
		set: function(a) {
			return h(this.options, a), a.touchAction && this.touchAction.update(), a.inputTarget && (this.input.destroy(), this.input.target = a.inputTarget, this.input.init()), this
		},
		stop: function(a) {
			this.session.stopped = a ? hc : gc
		},
		recognize: function(a) {
			var b = this.session;
			if (!b.stopped) {
				this.touchAction.preventDefaults(a);
				var c, d = this.recognizers,
					e = b.curRecognizer;
				(!e || e && e.state & dc) && (e = b.curRecognizer = null);
				for (var f = 0; f < d.length;) c = d[f], b.stopped === hc || e && c != e && !c.canRecognizeWith(e) ? c.reset() : c.recognize(a), !e && c.state & (ac | bc | cc) && (e = b.curRecognizer = c), f++
			}
		},
		get: function(a) {
			if (a instanceof T) return a;
			for (var b = this.recognizers, c = 0; c < b.length; c++)
				if (b[c].options.event == a) return b[c];
			return null
		},
		add: function(a) {
			if (f(a, "add", this)) return this;
			var b = this.get(a.options.event);
			return b && this.remove(b), this.recognizers.push(a), a.manager = this, this.touchAction.update(), a
		},
		remove: function(a) {
			if (f(a, "remove", this)) return this;
			var b = this.recognizers;
			return a = this.get(a), b.splice(s(b, a), 1), this.touchAction.update(), this
		},
		on: function(a, b) {
			var c = this.handlers;
			return g(r(a), function(a) {
				c[a] = c[a] || [], c[a].push(b)
			}), this
		},
		off: function(a, b) {
			var c = this.handlers;
			return g(r(a), function(a) {
				b ? c[a].splice(s(c[a], b), 1) : delete c[a]
			}), this
		},
		emit: function(a, b) {
			this.options.domEvents && fb(a, b);
			var c = this.handlers[a] && this.handlers[a].slice();
			if (c && c.length) {
				b.type = a, b.preventDefault = function() {
					b.srcEvent.preventDefault()
				};
				for (var d = 0; d < c.length;) c[d](b), d++
			}
		},
		destroy: function() {
			this.element && eb(this, !1), this.handlers = {}, this.session = {}, this.input.destroy(), this.element = null
		}
	}, h(cb, {
		INPUT_START: wb,
		INPUT_MOVE: xb,
		INPUT_END: yb,
		INPUT_CANCEL: zb,
		STATE_POSSIBLE: _b,
		STATE_BEGAN: ac,
		STATE_CHANGED: bc,
		STATE_ENDED: cc,
		STATE_RECOGNIZED: dc,
		STATE_CANCELLED: ec,
		STATE_FAILED: fc,
		DIRECTION_NONE: Ab,
		DIRECTION_LEFT: Bb,
		DIRECTION_RIGHT: Cb,
		DIRECTION_UP: Db,
		DIRECTION_DOWN: Eb,
		DIRECTION_HORIZONTAL: Fb,
		DIRECTION_VERTICAL: Gb,
		DIRECTION_ALL: Hb,
		Manager: db,
		Input: y,
		TouchAction: R,
		TouchInput: O,
		MouseInput: M,
		PointerEventInput: N,
		TouchMouseInput: Q,
		Recognizer: T,
		AttrRecognizer: X,
		Tap: bb,
		Pan: Y,
		Swipe: ab,
		Pinch: Z,
		Rotate: _,
		Press: $,
		on: n,
		off: o,
		each: g,
		merge: i,
		extend: h,
		inherit: j,
		bindFn: k,
		prefixed: v
	}), typeof define == ib && define.amd ? define(function() {
		return cb
	}) : "undefined" != typeof module && module.exports ? module.exports = cb : a[c] = cb
}(window, document, "Hammer");