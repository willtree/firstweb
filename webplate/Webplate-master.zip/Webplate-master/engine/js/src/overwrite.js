/**
 * File: overwrite.js
 * Type: Javascript Component Overwrite
 * Author: Chris Humboldt
 */

if (typeof $loaderplateDefault !== 'undefined') {
	$loaderplateDefault.path = web.url('baseUrl') + '/webplate/project/component/loaderplate/loaders/';
}